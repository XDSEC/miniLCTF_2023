可能出现的问题：

1. 

```
clang-15: error: unsupported option '--cxxflags`'
clang-15: error: unsupported option '--ldflags`'
clang-15: error: no such file or directory: '`llvm-config'
clang-15: error: no such file or directory: '`llvm-config'
```

这是由于你的bash不支持此命令的语法，请更换bash后重试

2. 

```
opt: Unknown command line argument '-YunZh1Jun'
```

这是不同版本LLVM的问题，请参见https://stackoverflow.com/questions/46690534/failed-to-test-llvm-llvmhello-pass-lib-llvmhello-so-undefined-symbol，重新构建LLVM可以解决此问题，出题环境为Ubuntu20.04 LLVM 10.0.0
