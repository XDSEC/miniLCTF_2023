Make sure that you have bulit LLVM, use `opt -load ./EasyPass.so -YunZh1Jun main.bc -o /dev/null` to run it under this directory.(Plz run it on Linux OS.)
You should find string "you_should_patch_this_flag" in EasyPass.so and patch it to right flag, then run it to check your flag.
Don't try to find the main logic by looping through all functions, you can try other effective methods.